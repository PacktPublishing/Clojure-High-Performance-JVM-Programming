(ns simple-macros.core)



(defn foo
  "I don't do a whole lot."
  [x]
  
  )
