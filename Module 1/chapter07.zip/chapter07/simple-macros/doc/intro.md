# Introduction to simple-macros

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
