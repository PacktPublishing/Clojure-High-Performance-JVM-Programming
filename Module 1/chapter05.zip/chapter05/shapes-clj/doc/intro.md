# Introduction to shapes-clj

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
