package shapes;

public interface Shape {
  public double getArea();
}

