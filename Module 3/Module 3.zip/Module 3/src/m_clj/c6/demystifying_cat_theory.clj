(ns m-clj.c6.demystifying-cat-theory)

;; user> (name :x)
;; "x"
;; user> (symbol "x")
;; x
;; user> ((comp symbol name) :x)
;; x
